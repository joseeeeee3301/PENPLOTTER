#include "lerTratarDados.h"

#include <Arduino.h>
#include <ESP32Servo.h>

Servo servoCaneta;

const int PINO_SERVO = 23;

const int ANGULO_LEVANTADA = 0;
const int ANGULO_ABAIXADA = 90;

bool estadoCaneta = false; //false para levantada e true para abaixada

void inicializarServoMotor(){
    servoCaneta.attach(PINO_SERVO);
    levantarCaneta();
}

void levantarServoCaneta(){
    servoCaneta.write(ANGULO_LEVANTADA);
}

void abaixarServoCaneta(){
    servoCaneta.write(ANGULO_ABAIXADA);
    estadoCaneta = true;
}

bool estadoCaneta(){
    return estadoCaneta;
}