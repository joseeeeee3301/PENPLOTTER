#include <Arduino.h>
#include <MultiStepper.h>

#include "motorX.h"
#include "motorY.h"

MultiStepper steppers;

void inicializarControleMotores(){
    steppers.addStepper(motorX);
    steppers.addStepper(motorY);
}

void moverMotores(long passosX, long passosY){
    long destino[2];
    
    destino[0] = passosX;
    destino[1] = passosY;

    steppers.moveTo(destino);

    steppers.runSpeedToPosition();
}