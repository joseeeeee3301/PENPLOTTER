#include <Arduino.h>
#include "motorX.h"
#include "motorY.h"
#include "lerTratarDadosUGS.h"
#include "controleMotores.h"
#include "servoMotor.h"

void setup() {
  Serial.begin(115200);
  inicializarMotorX();
  inicializarMotorY();
  inicializarControleMotores();
  inicializarServoMotor();
}

void loop() {
  // Executa um passo do movimento de forma não-bloqueante se necessário
  bool motoresAindaMovendo = atualizarMovimentoMultiStepper();

  if(movimentoEmExecucao == false){
    lerSerialUGS();
  }

  // RESPONDE OK PARA O UGS LIBERAR A PRÓXIMA LINHA SE OS MOTORES TERMINARAM O PERCURSO
  if(movimentoEmExecucao && !motoresAindaMovendo){
      movimentoEmExecucao  = false; // avisa que o movimento terminou
      Serial.println("ok");
  }
}