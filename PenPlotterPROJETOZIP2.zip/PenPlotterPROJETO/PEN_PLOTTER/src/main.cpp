#include <Arduino.h>
#include "motorX.h"
#include "motorY.h"
#include "lerTratarDadosUGS.h"

void setup() {
  Serial.begin(115200);
  
  inicializarMotorX();
  inicializarMotorY();
}

void loop() {
  atualizarMotorX();
  atualizarMotorY();

  if(movimentoEmExecucao == false){
    lerSerialUGS();
  }

  // RESPONDE OK PARA O UGS LIBERAR A PRÓXIMA LINHA SE OS MOTORES TERMINARAM O PERCUSO ANTERIOR
    if(movimentoEmExecucao && motorXTerminouPercuso() && motorYTerminouPercuso() == true){
        movimentoEmExecucao  = false; //avisa que o movimento terminou.
        Serial.println("ok");
    }
}