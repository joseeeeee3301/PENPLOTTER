#ifndef MOTORX_H
#define MOTORX_H

#include <Arduino.h>

void inicializarMotorY();
void atualizarMotorY();
void moverMotorY(long passosY);


#endif