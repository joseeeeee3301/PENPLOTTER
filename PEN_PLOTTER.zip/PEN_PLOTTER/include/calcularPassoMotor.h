#ifndef CALCULAR_PASSOS_MOTOR_H
#define CALCULAR_PASSOS_MOTOR_H

#include <Arduino.h>
#include "lerTratarDadosUGS.h"

void calcularPassoMotorX(const GCodeStruct& structGCode);
void calcularPassoMotorY(const GCodeStruct& structGCode);
#endif